﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Exa2.Models
{
    public class Operaciones
    {
        public double A
        {
            get;
            set;
        }
        public double B
        {
            get;
            set;
        }
       
        public double Result
        {
            get;
            set;
        }

    }
}


    

